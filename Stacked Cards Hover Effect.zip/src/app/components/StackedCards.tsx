import { motion } from 'motion/react';
import { useState } from 'react';
import imgAlbumcover00024652 from "figma:asset/b37a31598f917a664f0ce74be6cd3ca1ad3b33a3.png";
import img1112 from "figma:asset/cd2816545aef6f7ac4ac2e588a7f2a699ca357a7.png";
import imgLarge440ZFUyPtzh0R1DpPaydmNj1562290428780 from "figma:asset/354f08c9ee4c8b48b2b3139e78ae1409ca8d4f74.png";
import img3 from "figma:asset/8d577a0a4c6260820d35eedc5467eebf83d93437.png";
import imgAlbumcover0017530 from "figma:asset/3cda451e485ee11c5d31b1c4490c1d5c2e3ae030.png";

const cards = [
  {
    id: 1,
    image: imgAlbumcover00024652,
    left: 0,
    name: "albumcover0002465 2"
  },
  {
    id: 2,
    image: img1112,
    left: 62,
    name: "11 1 2"
  },
  {
    id: 3,
    image: imgLarge440ZFUyPtzh0R1DpPaydmNj1562290428780,
    left: 125,
    name: "large_440_zFUyPtzh0R1DpPaydmNj_1562290428780"
  },
  {
    id: 4,
    image: img3,
    left: 187,
    name: "Без названия 3"
  },
  {
    id: 5,
    image: imgAlbumcover0017530,
    left: 249,
    name: "albumcover0017530"
  }
];

export default function StackedCards() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  return (
    <div className="relative w-[452px] h-[202px] mx-auto">
      {cards.map((card, index) => (
        <motion.div
          key={card.id}
          className="absolute bg-center bg-cover bg-no-repeat h-[202px] w-[203px] cursor-pointer rounded-lg overflow-hidden shadow-lg"
          style={{ 
            backgroundImage: `url('${card.image}')`,
            left: `${card.left}px`,
            top: 0
          }}
          data-name={card.name}
          initial={{ rotate: 0, scale: 1 }}
          animate={{
            rotate: hoveredCard === card.id ? 0 : index * 2 - 4,
            scale: hoveredCard === card.id ? 1.1 : 1,
            zIndex: hoveredCard === card.id ? 50 : index
          }}
          whileHover={{
            scale: 1.1,
            rotate: 0,
            zIndex: 50,
            transition: { duration: 0.3, ease: "easeOut" }
          }}
          onHoverStart={() => setHoveredCard(card.id)}
          onHoverEnd={() => setHoveredCard(null)}
          transition={{
            duration: 0.3,
            ease: "easeOut"
          }}
        >
          {/* Overlay effect on hover */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"
            initial={{ opacity: 0 }}
            animate={{ opacity: hoveredCard === card.id ? 1 : 0 }}
            transition={{ duration: 0.2 }}
          />
          
          {/* Optional: Add a subtle border glow on hover */}
          <motion.div
            className="absolute inset-0 ring-2 ring-white/50 rounded-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: hoveredCard === card.id ? 1 : 0 }}
            transition={{ duration: 0.2 }}
          />
        </motion.div>
      ))}
    </div>
  );
}