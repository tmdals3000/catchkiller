import StackedCards from './components/StackedCards';
import StackedCardsAdvanced from './components/StackedCardsAdvanced';
import { useState } from 'react';

export default function App() {
  const [activeDemo, setActiveDemo] = useState<'basic' | 'advanced'>('basic');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-4xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl text-gray-800">Album Collection</h1>
          <p className="text-xl text-gray-600">Interactive stacked cards with hover effects</p>
          
          {/* Toggle buttons */}
          <div className="flex justify-center gap-4 mt-8">
            <button
              onClick={() => setActiveDemo('basic')}
              className={`px-6 py-3 rounded-lg transition-all duration-200 ${
                activeDemo === 'basic'
                  ? 'bg-gray-800 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-100 shadow'
              }`}
            >
              Basic Animation
            </button>
            <button
              onClick={() => setActiveDemo('advanced')}
              className={`px-6 py-3 rounded-lg transition-all duration-200 ${
                activeDemo === 'advanced'
                  ? 'bg-gray-800 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-100 shadow'
              }`}
            >
              Advanced Effects
            </button>
          </div>
        </div>

        {/* Demo section */}
        <div className="flex justify-center">
          {activeDemo === 'basic' ? <StackedCards /> : <StackedCardsAdvanced />}
        </div>

        {/* Description */}
        <div className="text-center space-y-4">
          {activeDemo === 'basic' ? (
            <div className="max-w-2xl mx-auto">
              <h3 className="text-xl text-gray-700 mb-2">Basic Animation</h3>
              <p className="text-gray-600">
                Clean hover effects with scaling, rotation, and smooth transitions. 
                Each card scales up and rotates to the front while maintaining the original design.
              </p>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto">
              <h3 className="text-xl text-gray-700 mb-2">Advanced Effects</h3>
              <p className="text-gray-600">
                Enhanced version with image transitions, information overlays, and dramatic animations. 
                Hover to see images change, cards lift up, and detailed album information appear.
              </p>
            </div>
          )}
        </div>

        {/* Features list */}
        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h4 className="font-medium text-gray-800 mb-3">Basic Features</h4>
            <ul className="space-y-2 text-gray-600">
              <li>• Smooth scale animations</li>
              <li>• Rotation effects</li>
              <li>• Dynamic z-index</li>
              <li>• Subtle overlays</li>
              <li>• Preserved original design</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h4 className="font-medium text-gray-800 mb-3">Advanced Features</h4>
            <ul className="space-y-2 text-gray-600">
              <li>• Image crossfade transitions</li>
              <li>• Vertical lift animations</li>
              <li>• Information overlays</li>
              <li>• Enhanced visual effects</li>
              <li>• Album metadata display</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}